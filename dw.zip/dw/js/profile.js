import { api } from './api.js';

const profile = {
    async init() {
        try {
            const data = await api.request('/api/profile');
            document.getElementById('userName').textContent = data.user.username;
            document.getElementById('userAvatar').src = `http://localhost:3000${data.user.avatar_url}`;
            this.renderTracks(data.tracks);
        } catch (e) {
            window.location.href = 'auth.html';
        }

        document.getElementById('avatarInput').addEventListener('change', (e) => this.uploadAvatar(e));
        document.getElementById('trackUploadInput').addEventListener('change', (e) => this.uploadTrack(e));
        document.getElementById('logoutBtn').addEventListener('click', () => {
            localStorage.clear();
            window.location.href = 'auth.html';
        });
    },

    async uploadAvatar(e) {
        const formData = new FormData();
        formData.append('avatar', e.target.files[0]);
        const res = await api.request('/api/upload-avatar', 'POST', formData, true);
        document.getElementById('userAvatar').src = `http://localhost:3000${res.path}`;
    },

    async uploadTrack(e) {
        const file = e.target.files[0];
        const formData = new FormData();
        formData.append('file', file);
        formData.append('track_name', file.name);
        await api.request('/api/upload-track', 'POST', formData, true);
        location.reload();
    },

    renderTracks(tracks) {
    const list = document.getElementById('tracksList');
    const countEl = document.getElementById('statTracksCount');
    
    countEl.textContent = tracks.length;

    list.innerHTML = tracks && tracks.length ? '' : '<p style="color: var(--text-secondary); text-align: center; padding: 20px;">Треков пока нет</p>';
    
    tracks.forEach((track, index) => {
        list.innerHTML += `
            <div class="track-item" style="animation-delay: ${index * 0.1}s">
                <div class="track-item-left">
                    <div class="track-icon">🎵</div>
                    <a href="/html/inplayer.html?track=${encodeURIComponent(track.file_path)}">
                        ${track.track_name}
                    </a>
                </div>
                <div class="track-meta">
                    MP3 / 320kbps
                </div>
            </div>`;
    });
}
}
profile.init();
