(function() {
    'use strict';

    async function updateNav() {
        const token = localStorage.getItem('token');
        const navProfile = document.getElementById('navProfile');
        const miniUsername = document.getElementById('miniUsername');
        const miniAvatar = document.getElementById('miniAvatar');
        
        if (!navProfile) return;

        if (!token) {
            navProfile.innerHTML = '<span class="icon"></span> <span>Вход</span>';
            navProfile.href = '/html/auth.html';
            if (miniUsername) miniUsername.textContent = 'Guest';
            if (miniAvatar) miniAvatar.src = 'https://via.placeholder.com/100';
        } else {
            navProfile.innerHTML = '<span class="icon"></span> <span>Профиль</span>';
            navProfile.href = '/html/profile.html';

            try {
                const response = await fetch('http://localhost:3000/api/profile', {
                    headers: { 'Authorization': token }
                });

                if (response.ok) {
                    const data = await response.json();
                    if (miniUsername) miniUsername.textContent = data.user.username;
                    if (miniAvatar) miniAvatar.src = `http://localhost:3000${data.user.avatar_url}`;
                } else {
                    throw new Error('Session expired');
                }
            } catch (e) {
                localStorage.clear();
                window.location.href = '/html/auth.html';
            }
        }

        const currentPage = window.location.pathname;
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === currentPage) {
                link.classList.add('active');
            }
        });
    }

    window.addEventListener('DOMContentLoaded', updateNav);
})();
