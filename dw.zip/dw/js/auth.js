import { api } from './api.js';

const authLogic = {
    toggleForm: function() {
        const loginForm = document.getElementById('loginForm');
        const regForm = document.getElementById('regForm');
        if (loginForm.style.display === 'none') {
            loginForm.style.display = 'block';
            regForm.style.display = 'none';
        } else {
            loginForm.style.display = 'none';
            regForm.style.display = 'block';
        }
    },
    async register() {
        const username = document.getElementById('regUser').value;
        const password = document.getElementById('regPass').value;
        try {
            await api.request('/api/register', 'POST', { username, password });
            alert('Регистрация успешна!');
            this.toggleForm();
        } catch (e) { alert(e.error || 'Ошибка регистрации'); }
    },
        async login() {
        const username = document.getElementById('loginUser').value;
        const password = document.getElementById('loginPass').value;
        try {
            const data = await api.request('/api/login', 'POST', { username, password });
            localStorage.setItem('token', data.token);
            localStorage.setItem('username', data.username);
            window.location.href = '/html/profile.html';
        } catch (e) { 
            alert('Неверный логин или пароль'); 
        }
    }

};

window.auth = authLogic;
