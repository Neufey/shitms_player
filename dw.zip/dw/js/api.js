const API_URL = 'http://localhost:3000';

export const api = {
    async request(endpoint, method = 'GET', data = null, isFile = false) {
        const token = localStorage.getItem('token');
        const headers = {};
        if (!isFile) headers['Content-Type'] = 'application/json';
        if (token) headers['Authorization'] = token;

        const options = { method, headers };
        if (data && !isFile) options.body = JSON.stringify(data);
        if (data && isFile) options.body = data;

        const res = await fetch(`${API_URL}${endpoint}`, options);
        if (!res.ok) {
            const error = await res.json();
            throw error;
        }
        return res.json();
    }
};
