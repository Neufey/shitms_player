const express = require('express');
const { open } = require('sqlite');
const sqlite3 = require('sqlite3');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

const app = express();
const JWT_SECRET = 'my_super_secret_key_123';

app.use(cors());
app.use(express.json());

app.use('/html', express.static(path.join(__dirname, 'html')));
app.use('/css', express.static(path.join(__dirname, 'css')));
app.use('/js', express.static(path.join(__dirname, 'js')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

if (!fs.existsSync('./uploads')) fs.mkdirSync('./uploads');

let db;

async function initDB() {
    db = await open({
        filename: './database.sqlite',
        driver: sqlite3.Database
    });
    await db.exec(`
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            avatar_url TEXT DEFAULT 'https://via.placeholder.com/100'
        );
        CREATE TABLE IF NOT EXISTS tracks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            track_name TEXT NOT NULL,
            file_path TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        );
    `);
    console.log('✅ SQLite Database Ready');
}

const storage = multer.diskStorage({
    destination: './uploads/',
    filename: (req, file, cb) => cb(null, Date.now() + path.extname(file.originalname))
});
const upload = multer({ storage });

app.post('/api/register', async (req, res) => {
    const { username, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    try {
        await db.run('INSERT INTO users (username, password) VALUES (?, ?)', [username, hashedPassword]);
        res.json({ message: 'User created' });
    } catch (e) { res.status(400).json({ error: 'Никнейм занят' }); }
});

app.post('/api/login', async (req, res) => {
    const { username, password } = req.body;
    const user = await db.get('SELECT * FROM users WHERE username = ?', [username]);
    if (user && await bcrypt.compare(password, user.password)) {
        const token = jwt.sign({ userId: user.id }, JWT_SECRET);
        res.json({ token, username: user.username });
    } else { res.status(401).json({ error: 'Ошибка входа' }); }
});

app.get('/api/profile', async (req, res) => {
    const token = req.headers.authorization;
    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        const user = await db.get('SELECT * FROM users WHERE id = ?', [decoded.userId]);
        const tracks = await db.all('SELECT * FROM tracks WHERE user_id = ?', [decoded.userId]);
        res.json({ user, tracks });
    } catch (e) { res.status(401).json({ error: 'Нет доступа' }); }
});

app.post('/api/upload-track', upload.single('file'), async (req, res) => {
    const token = req.headers.authorization;
    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        const filePath = `/uploads/${req.file.filename}`;
        await db.run('INSERT INTO tracks (user_id, track_name, file_path) VALUES (?, ?, ?)', 
            [decoded.userId, req.body.track_name, filePath]);
        res.json({ success: true, path: filePath });
    } catch (e) { res.status(401).send('Ошибка'); }
});

app.post('/api/upload-avatar', upload.single('avatar'), async (req, res) => {
    const token = req.headers.authorization;
    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        const filePath = `/uploads/${req.file.filename}`;
        await db.run('UPDATE users SET avatar_url = ? WHERE id = ?', [filePath, decoded.userId]);
        res.json({ success: true, path: filePath });
    } catch (e) { res.status(401).send('Ошибка'); }
});

initDB().then(() => {
    app.listen(3000, () => console.log('🚀 Server: http://localhost:3000/html/inplayer.html'));
});
